<?php

session_start();

if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit;
}

include("Conectare.php");

if (!empty($_GET['id'])) {
	$articleId = $_GET['id'];
	$activationValue = 1;
	
	if ($stmt = $mysqli->prepare("UPDATE article SET active=? WHERE id=?")) {
		$stmt->bind_param("ii", $activationValue, $articleId);
		$stmt->execute();
        $stmt->close();
 	}
 	else {
		echo "ERROR: nu se poate executa update pe articolul selectat.";
	}	
}

header('Location: Vizualizare.php');
?>