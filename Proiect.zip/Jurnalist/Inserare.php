<?php
session_start();

if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit;
}
?>

<?php
 include("Conectare.php");
 
 $error='';
 
 if (isset($_POST['submit'])) {
 
 $name = htmlentities($_POST['name'], ENT_QUOTES);
 $author = htmlentities($_POST['author'], ENT_QUOTES);
 $content = htmlentities($_POST['content'], ENT_QUOTES);
 $date = htmlentities($_POST['date'], ENT_QUOTES);
 $category = htmlentities($_POST['category'], ENT_QUOTES);
 $active = 0;

 if ($name == '' || $author == ''|| $content == ''|| $date == '' || $date == ''|| $category == '') {
	$error = 'ERROR: Campuri goale!';
 } else {
 if ($stmt = $mysqli->prepare("INSERT into article (name, author, content, date, category, active) VALUES (?, ?, ?, ?, ?, ?)")) {
	$stmt->bind_param("sssssi", $name, $author, $content, $date, $category, $active);
	$stmt->execute();
	$stmt->close();
	echo "Articol adaugat cu succes! <br/>";
 } else {
	echo "ERROR: Nu se poate executa insert. <br/>";
 }}}

 $mysqli->close();
?>

<html>
 <head>
	<title><?php echo "Inserare articol"; ?> </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
 </head> 
 <body>
 	<a href="Vizualizare.php">Vizualizare lista articole</a>
	</br>
	<a href="logout.php">Logout</a>
 
	<h1><?php echo "Inserare articol"; ?></h1>
	<?php if ($error != '') {
		echo "<div style='padding:4px; border:1px solid red; color:red'>" . $error."</div>";} ?>
	<form action="" method="post">
	<div>
	<strong>Nume: </strong> <input type="text" name="name" value=""/> <br/>
	<strong>Autor: </strong> <input type="text" name="author" value=""/> <br/>
	<strong>Continut: </strong> <textarea name="content">Articol ...</textarea> <br/>
	<strong>Data publicare: </strong> <input type="date" name="date" value=""/> <br/>
	<strong>Categorii: </strong> <br/>
	<input type="radio" id="artistic" name="category" value="Artistic" checked="checked">
    <label for="artistic">Artistic</label> <br/>
    <input type="radio" id="technic" name="category" value="Technic">
    <label for="technic">Technic</label> <br/>
    <input type="radio" id="science" name="category" value="Science">
    <label for="science">Science</label> <br/>
	<input type="radio" id="moda" name="category" value="Moda">
    <label for="moda">Moda</label> <br/>
	<br/>
	<input type="submit" name="submit" value="Submit" />
	</div>
	</form>
 </body>
</html>