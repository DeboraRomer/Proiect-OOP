<?php
$hostname = 'localhost';
$username = 'root';
$password = '';
$db = 'jurnalism';

$mysqli = new mysqli($hostname, $username, $password, $db);

if(mysqli_connect_errno()) {
	echo 'Conectare la baza de date esuata';
	exit();
}
?>