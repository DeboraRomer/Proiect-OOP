<?php

session_start();

if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit;
}
?>
<html>
 	<head>
 		<title>Vizualizare Articole</title>
 		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
 </head>
 <body> 	<a href="Inserare.php">Adauga un nou articol</a>		</br>	<a href="logout.php">Logout</a> 	<h1>Vizualizare Articole</h1><?php include("Conectare.php"); if ($result = $mysqli->query("SELECT * FROM article ORDER BY id")) { 	if ($result->num_rows > 0) {		$articleMapping = array();		while ($row = $result->fetch_object()) {			$listOfArticles;			if (array_key_exists($row->category, $articleMapping)) {				$articleMapping[$row->category];			} else {				$listOfArticles = array();			}			array_push($listOfArticles, $row);			$articleMapping[$row->category] = $listOfArticles;		}				foreach($articleMapping as $category => $articleList) {			echo "<h3/>". $category . "<h3/>";						echo "<table border='1' cellpadding='10'>";			echo "<tr><th>ID</th><th>Nume</th><th>Autor</th><th>Continut</th><th>Data publicare</th><th>Activ</th><th></th></tr>";						foreach($articleList as $article) {				echo "<tr>";				echo "<td>" . $article->id . "</td>";				echo "<td>" . $article->name . "</td>";				echo "<td>" . $article->author . "</td>";				echo "<td>" . $article->content . "</td>";				echo "<td>" . $article->date . "</td>";							$activeStatus = ($article->active == 1) ? "activ" : "in asteptare";					echo "<td>" . $activeStatus . "</td>";				echo "<td><a href='Activare.php?id=" . $article->id . "'>Activeaza</a></td>";				echo "</tr>";			}						echo "</table>";		}	} 	else {		echo "Nu sunt inregistrari in tabela!";	}} else { 	echo "Error:" . $mysqli->error(); } $mysqli->close(); ?> </body></html>