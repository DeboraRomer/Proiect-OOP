<?php
session_start();

include("Conectare.php");

if ( !isset($_POST['username'], $_POST['password']) ) {
	
	exit('Completati ambele campuri username si password !');
}

if ($stmt = $mysqli->prepare('SELECT id, password FROM editor WHERE username = ?')) {
	
	$stmt->bind_param('s', $_POST['username']);
	$stmt->execute();
	
	$stmt->store_result();

if ($stmt->num_rows > 0) {
	$stmt->bind_result($id, $password);
	$stmt->fetch();
	
	if (password_verify($_POST['password'], $password)) {
				session_regenerate_id();
		$_SESSION['loggedin'] = TRUE;
		$_SESSION['name'] = $_POST['username'];
		$_SESSION['id'] = $id;
		header('Location: Vizualizare.php');
	} else {
		
		
	echo 'Username si/sau password incorect!';
	}
} else {
	
	echo 'Username si/sau password incorect!';
}
	$stmt->close();
}
?>