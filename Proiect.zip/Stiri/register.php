<?php

include("Conectare.php");
 
if (!isset($_POST['username'], $_POST['password'], $_POST['email'])) {
	exit('Completati formular!');
}

if (empty($_POST['username']) || empty($_POST['password']) || empty($_POST['email'])) {	
	exit('Completati formular!');
}

if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
	exit('Email nu este valid!');
}

if (preg_match('/[A-Za-z0-9]+/', $_POST['username']) == 0) {
    exit('Username nu este valid!');
}

if (strlen($_POST['password']) > 20 || strlen($_POST['password']) < 5) {
	exit('Password trebuie sa fie intre 5 si 20 charactere!');
}

if ($stmt = $mysqli->prepare('SELECT id, password FROM reader WHERE username = ?')) {
	$stmt->bind_param('s', $_POST['username']);
	$stmt->execute();
	$stmt->store_result();
	
	if ($stmt->num_rows > 0) {
		echo 'Username exista deja, se alege altul!';
	} else {
		if ($stmt = $mysqli->prepare('INSERT INTO reader (username, password, email) VALUES (?, ?, ?)')) {
	
		$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
		$stmt->bind_param('sss', $_POST['username'], $password, $_POST['email']);
		$stmt->execute();
	
		echo 'Contul de cititor a fost creat cu succes! <br/>';
		
		echo '<a href="login.html">Login</a>';
	
	    echo '<br/>';

	    echo '<a href="index.php">Articole</a>';
} else {
	echo 'Nu s-a putut crea contul de cititor!';
}}} else {
	echo 'Nu s-a putut crea contul de cititor';
}

$mysqli->close();

?>