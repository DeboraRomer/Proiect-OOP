<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
	header('Location: login.html');
	exit;
}
?>
<html>
 	<head>
 		<title>Vizualizare Articol</title>
 		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
 </head>
 <body> 	<a href="index.php">Lista articole</a>		</br>	<a href="logout.php">Logout</a> <?php include("Conectare.php");  if (!empty($_GET['id'])) {	$articleId = $_GET['id'];	$activationValue = 1;		if ($stmt = $mysqli->prepare("SELECT name, author, date, category, content FROM article WHERE id=? AND active=?")) {		$stmt->bind_param("ii", $articleId, $activationValue);		$stmt->execute();		$stmt->store_result();						if ($stmt->num_rows > 0) {			$stmt->bind_result($name, $author, $date, $category, $content);						while($stmt->fetch()) {				echo "<h1>" . $name . "</h1>";								echo "<div><p><strong>Autor:</strong> " . $author . "</p>";							echo "<p><strong>Data publicare:</strong> " . $date . "</p>";							echo "<p><strong>Categorie:</strong> " . $category . "</p></div>";							echo "<div>" . $content . "</div>";							}		}				$stmt->close(); 	} 	else {		echo "ERROR: nu s-a gasit articolul selectat.";	}	 } else {	 echo "Articolul cautat nu exista"; }  $mysqli->close(); ?> </body></html>