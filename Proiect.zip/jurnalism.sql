-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 17, 2023 at 02:28 PM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jurnalism`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
CREATE TABLE IF NOT EXISTS `article` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` char(30) NOT NULL,
  `author` char(30) NOT NULL,
  `content` text NOT NULL,
  `date` date NOT NULL,
  `category` char(30) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`id`, `name`, `author`, `content`, `date`, `category`, `active`) VALUES
(2, 'Test 2', 'Test 2', 'Test 2', '2023-01-01', 'Technic', 1),
(3, 'Test 3', 'Test 3', 'Articol ...', '2023-01-01', 'Science', 1),
(4, 'Test 4', 'Test 4', 'Articol ...', '2023-01-02', 'Technic', 0),
(5, 'Test 5', 'Test 5', 'Articol ...', '2023-01-04', 'Technic', 0);

-- --------------------------------------------------------

--
-- Table structure for table `editor`
--

DROP TABLE IF EXISTS `editor`;
CREATE TABLE IF NOT EXISTS `editor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` char(20) NOT NULL,
  `password` char(64) NOT NULL,
  `email` char(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `editor`
--

INSERT INTO `editor` (`id`, `username`, `password`, `email`) VALUES
(1, 'admin', '$2y$10$u0UqADw47cyTyXQA5jZMT.j0wYAbiypV2GCmEstGISKmOhb2CBbaq', 'admin@email.com');

-- --------------------------------------------------------

--
-- Table structure for table `reader`
--

DROP TABLE IF EXISTS `reader`;
CREATE TABLE IF NOT EXISTS `reader` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` char(20) NOT NULL,
  `password` char(64) NOT NULL,
  `email` char(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `reader`
--

INSERT INTO `reader` (`id`, `username`, `password`, `email`) VALUES
(1, 'client1', '$2y$10$Osxu1n8ufdqQ2TkOpM4z3eztg3nEgrVaMvfYrPQXB.eleq.QEshQ6', 'client1@email.com'),
(3, 'cititor1', '$2y$10$2y2e94sFXMym3tATBDtYEuaCvMSjPhU2YNSB9tqawkNNI4zFqAm6m', 'cititor1@mail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
